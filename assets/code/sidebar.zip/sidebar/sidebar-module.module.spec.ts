import { SidebarModuleModule } from './sidebar-module.module';

describe('SidebarModuleModule', () => {
  let sidebarModuleModule: SidebarModuleModule;

  beforeEach(() => {
    sidebarModuleModule = new SidebarModuleModule();
  });

  it('should create an instance', () => {
    expect(sidebarModuleModule).toBeTruthy();
  });
});
