import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges, OnChanges } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  @Input() display: boolean = true;
  @Output() onClose = new EventEmitter<boolean>();
  menu:any[]=[
    {id:1,name:'Home'},
    {id:2,name:'About'},
    {id:3,name:'Feedback'},
    {id:4,name:'Help'},
    {id:5,name:'Settings'}

  ]
  constructor() { }
  
  ngOnInit() {
document.getElementById("mySidenav").style.width = "250px";
  }

  closeNav(){
  
   this.Close();
   this.onClose.emit();
  }

  private Close(){
    this.display=false;
    
  }

}
