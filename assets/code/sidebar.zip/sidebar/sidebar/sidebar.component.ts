import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges, OnChanges } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit, OnChanges {
  @Input() display: boolean;
  @Output() onClose = new EventEmitter<boolean>();
  menu:any[]=[
    {id:1,name:'Home'},
    {id:2,name:'About'},
    {id:3,name:'Feedback'},
    {id:4,name:'Help'},
    {id:5,name:'Settings'}

  ]
  constructor() { }
  ngOnChanges(changes: SimpleChanges){
    if(changes.display.previousValue === false){
      document.getElementById("mySidenav").style.width = "250px";
    }else{
      this.Close();
      this.onClose.emit();
    }
  }
  ngOnInit() {
  }

  closeNav(){
  
   this.Close();
   this.onClose.emit();
  }

  private Close(){
    this.display=false;
    document.getElementById("mySidenav").style.width = "0";
  }

}
