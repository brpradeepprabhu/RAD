import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';

//samplerouting


@NgModule({
    declarations: [
    ],
    imports: [
        RouterModule.forRoot([
           //samplimport
        ])
    ],
    exports: [
        RouterModule,
    ],
    providers: [],

})
export class AppRoutingModule { }



