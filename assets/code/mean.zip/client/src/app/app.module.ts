import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { DropdownModule } from 'primeng/dropdown';
import { CalendarModule } from 'primeng/calendar';
import { AppComponent } from './app.component';
import { SpinnerModule } from 'primeng/spinner';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

//importmenumodule

@NgModule({
    declarations: [ AppComponent],
    imports: [ BrowserModule, DropdownModule, CalendarModule, SpinnerModule,BrowserAnimationsModule,
//menumodule
 ],
    providers: [],
    bootstrap: [ AppComponent ] 
})
export class AppModule {}
