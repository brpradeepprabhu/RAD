import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { DropdownModule } from 'primeng/dropdown';
import { CalendarModule } from 'primeng/calendar';
import { AppComponent } from './app.component';
import { SpinnerModule } from 'primeng/spinner';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';



@NgModule({
    declarations: [ AppComponent],
    imports: [ BrowserModule, DropdownModule, CalendarModule, SpinnerModule,BrowserAnimationsModule ],
    providers: [],
    bootstrap: [ AppComponent ] 
})
export class AppModule {}
