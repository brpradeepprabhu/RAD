var config = {
	app: {
		port: 3000
	},
	db: {
		host: 'localhost',
		name: 'testDB',
		port: 27017
	}
};

module.exports = config;
