let express = require('express');
let app = express();
let bodyParser = require('body-parser');
let cors = require('cors');

app.use(cors());

app.use(
	bodyParser.urlencoded({
		extended: true
	})
);
app.use(bodyParser.json());


app.listen('3000', function () {
	console.log('running on 3000');
});
