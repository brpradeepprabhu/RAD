let express = require('express');
let app = express();
let bodyParser = require('body-parser');
let cors = require('cors');
let mongoose = require('mongoose');
let config = require('./config/config');
console.log(config.db.host + ':' + config.db.port + '/' + config.db.name);
if (!config.db.username) {
	mongoose.connect('mongodb://' + config.db.host + ':' + config.db.port + '/' + config.db.name);
} else {
	mongoose.connect(
		'mongodb://' +
			config.db.username +
			':' +
			config.db.password +
			'@' +
			config.db.host +
			':' +
			config.db.port +
			'/' +
			config.db.name
	);
}
app.use(cors());
let db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function () {
    console.log("connected")
});

app.use(
	bodyParser.urlencoded({
		extended: true
	})
);
app.use(bodyParser.json());

app.listen('3000', function() {
	console.log('running on 3000');
});

